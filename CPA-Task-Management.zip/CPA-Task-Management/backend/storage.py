import firebase_admin
from firebase_admin import credentials, storage
from fastapi import UploadFile, HTTPException
import uuid

cred = credentials.Certificate("D:/cpa-task-management-85c07-firebase-adminsdk-fbsvc-95ed996804.json")  
firebase_admin.initialize_app(cred, {
    'storageBucket': 'your-project-id.appspot.com'  
})

bucket = storage.bucket()

def upload_file(file: UploadFile) -> str:
    """
    Uploads a file to Firebase Storage and returns its public URL.
    """
    try:
        file_id = str(uuid.uuid4())
        blob = bucket.blob(f"uploads/{file_id}_{file.filename}")
        blob.upload_from_file(file.file, content_type=file.content_type)
        blob.make_public()
        return blob.public_url
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

def download_file(file_path: str) -> bytes:
    """
    Downloads a file from Firebase Storage and returns its binary content.
    """
    try:
        blob = bucket.blob(file_path)
        if not blob.exists():
            raise HTTPException(status_code=404, detail="File not found")
        return blob.download_as_bytes()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")
