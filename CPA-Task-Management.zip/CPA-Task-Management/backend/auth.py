import firebase_admin
from firebase_admin import credentials, auth
from fastapi import HTTPException, Header
from typing import Optional

cred = credentials.Certificate("D:/cpa-task-management-85c07-firebase-adminsdk-fbsvc-95ed996804.json")  
default_app = firebase_admin.initialize_app(cred)

def verify_token(authorization: Optional[str] = Header(None)) -> str:
    """
    Verifies the Firebase Auth ID token passed in the Authorization header.
    Returns the UID of the authenticated user if valid.
    Raises HTTPException if invalid or missing.
    """
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization header")

    try:
        id_token = authorization.split("Bearer ")[-1]
        decoded_token = auth.verify_id_token(id_token)
        uid = decoded_token.get("GOtGtGoK2cYHvcCH61qmYKyDe0L2")
        return uid
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Invalid token: {str(e)}")
