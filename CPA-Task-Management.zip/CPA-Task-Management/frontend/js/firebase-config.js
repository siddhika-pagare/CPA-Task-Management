import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyA3qaUC-p8H7lJ2kSUJXmeKCcfozW8twaw",
  authDomain: "cpa-task-management-85c07.firebaseapp.com",
  projectId: "cpa-task-management-85c07",
  storageBucket: "cpa-task-management-85c07.firebasestorage.app",
  messagingSenderId: "260851361836",
  appId: "1:260851361836:web:bcd0e51756635cac218989",
  measurementId: "G-GVYJ719K1G"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };
